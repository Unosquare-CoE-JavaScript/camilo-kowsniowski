import Giftlist from "./components/Giftlist";

function App() {
  const BdayList = [
    {
      id: "e1",
      gift: "PS5",
      amount: 5,
      date: new Date(2022, 9, 1),
    },
    {
      id: "e2",
      gift: "Xbox one series X",
      amount: 3,
      date: new Date(2022, 1, 5),
    },
    {
      id: "e3",
      gift: "Bike",
      amount: 10,
      date: new Date(2022, 3, 1),
    },
    {
      id: "e4",
      gift: "Macbook Pro m1",
      amount: 3,
      date: new Date(2022, 8, 1),
    },
  ];
  return (
    <div className="App">
      <h1>Lista de regalos</h1>
      <Giftlist
        gift={BdayList[0].gift}
        amount={BdayList[0].amount}
        date={BdayList[0].date}
      />
      <Giftlist
        gift={BdayList[1].gift}
        amount={BdayList[1].amount}
        date={BdayList[1].date}
      />
      <Giftlist
        gift={BdayList[2].gift}
        amount={BdayList[2].amount}
        date={BdayList[2].date}
      />
      <Giftlist
        gift={BdayList[3].gift}
        amount={BdayList[3].amount}
        date={BdayList[3].date}
      />
    </div>
  );
}

export default App;
