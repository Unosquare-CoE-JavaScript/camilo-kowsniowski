import "./Styles.css";

function GiftDates(props) {
  // declaramos las propiedades de date

  const month = props.date.toLocaleString("en", { mont: "long" });
  const year = props.date.toLocaleString("en", { day: "2-digit" });
  const day = props.date.getFullYear();
  return (
    <div className="date">
      <div className="month">{month}</div>
      <div className="year">{year}</div>
      <div className="day">{day}</div>
    </div>
  );
}

export default GiftDates;
