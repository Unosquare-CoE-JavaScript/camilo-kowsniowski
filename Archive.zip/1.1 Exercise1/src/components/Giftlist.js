import GiftDates from "./GiftDates";
import "./Styles.css";

function Giftlist(props) {
  return (
    <div className="item">
      {/* los datos de los regalos */}
      <GiftDates date={props.date} />

      <div className="descrip">
        <div className="count">{props.amount}</div>
        <h3>{props.gift}</h3>
      </div>
    </div>
  );
}

export default Giftlist;
