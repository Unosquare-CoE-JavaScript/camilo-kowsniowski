#introduction

contenido del curso

*Pasos para deplegar una app
*rutas del lado del servidor y rutas del lado del cliente

\*Pasos para deplegar una app

- Realizar puebas unitarias
- Optimizar el codigo (Lazy Loading,Suspense)
- Ejecutar Build para poduccion (npm rund Build)
- subir a un servidor el codigo de produccion (Firebase, Netlify, Surge)
- confirgurar el servidor

https://quoteskosniowski.web.app
