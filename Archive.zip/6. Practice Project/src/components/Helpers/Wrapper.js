// componente vcacio que sirve como envoltorio
const Wrapper = (props) => {
  return props.children;
};

export default Wrapper;
